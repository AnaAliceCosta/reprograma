$(document).ready(function(){
    $('#animate').click(function(){
        $('#content').animate({ "width": "60%", "padding-top": "100px" }, 10000);
    });
});